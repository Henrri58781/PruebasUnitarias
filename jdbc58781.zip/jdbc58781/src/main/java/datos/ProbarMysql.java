package datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ProbarMysql {

    public static void main(String[] args) throws SQLException {
        // [1] Cadena de conexión

        String url = "jdbc:mysql://localhost:3306/mvc58781?"
                + "useSSL=false"
                + "&useTimezone=true"
                + "&serverTimezone=UTC"
                + "&allowPublicKeyRestrieval=true";

        //[3] Sentencia sql
        try ( //[2] Conector de BD
                Connection conn = DriverManager.getConnection(url, "mvc58781", "mvc2103")) {
            //[3] Sentencia sql
            Statement stmt = conn.createStatement();
            
            //[4] Query
            String sql = "SELECT * FROM profesores WHERE id=1";
            
            // [5] Ejecutar Query
            ResultSet rs = stmt.executeQuery(sql);
            
            // [6] Resultados
            while (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                String paterno = rs.getString("paterno");
                String materno = rs.getString("materno");
                System.out.println("Id: "+id+" Nombre: "+nombre+" Paterno: "+paterno+ " Materno: "+materno);
            }
            rs.close();
            stmt.close();
        }
        
    }

}
